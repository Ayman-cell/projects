const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');
require('dotenv').config();
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(cors());
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(express.json({ limit: '100kb' }));

// Basic rate limiting for API endpoints
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
app.use('/api/', apiLimiter);

// Serve static files (same-origin frontend)
app.use(express.static(path.join(__dirname)));

const PAYPAL_API = 'https://api-m.paypal.com'; // live endpoint
const CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET;

// Get OAuth2 access token
async function getAccessToken() {
  const auth = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
  const res = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });
  const data = await res.json();
  return data.access_token;
}

// Create order
app.post('/api/paypal/create-order', async (req, res) => {
  const { amount } = req.body;
  try {
    const accessToken = await getAccessToken();
    const orderRes = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{
          amount: { currency_code: 'USD', value: amount }
        }],
        application_context: {
          return_url: 'https://starteady.com/success',
          cancel_url: 'https://starteady.com/cancel'
        }
      })
    });
    const orderData = await orderRes.json();
    res.json({ id: orderData.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Capture order
app.post('/api/paypal/capture-order', async (req, res) => {
  const { orderID } = req.body;
  try {
    const accessToken = await getAccessToken();
    const captureRes = await fetch(`${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      }
    });
    const captureData = await captureRes.json();
    res.json(captureData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Contact endpoint (server-side Airtable integration)
app.post('/api/contact', async (req, res, next) => {
  try {
    const { name, email, company = '', service, message = '' } = req.body || {};

    if (!name || !email || !service) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, error: 'Invalid email' });
    }

    // Server-side Airtable call (use env vars, not client-exposed)
    const { AIRTABLE_BASE_ID, AIRTABLE_API_KEY, AIRTABLE_TABLE_NAME } = process.env;
    if (!AIRTABLE_BASE_ID || !AIRTABLE_API_KEY || !AIRTABLE_TABLE_NAME) {
      return res.status(500).json({ success: false, error: 'Airtable not configured' });
    }

    const url = `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${encodeURIComponent(AIRTABLE_TABLE_NAME)}`;
    const payload = {
      fields: {
        Name: name,
        Email: email,
        Company: company,
        Service: service,
        Message: message,
        'Date Submitted': new Date().toISOString()
      }
    };

    const atRes = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${AIRTABLE_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!atRes.ok) {
      const errData = await atRes.json().catch(() => ({}));
      const msg = errData?.error?.message || `Airtable error ${atRes.status}`;
      return res.status(502).json({ success: false, error: msg });
    }

    const created = await atRes.json();
    return res.json({ success: true, id: created?.id || null });
  } catch (error) {
    next(error);
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not Found' });
});

// Centralized error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));