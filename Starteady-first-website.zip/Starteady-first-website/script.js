// Modern JavaScript for Starteady Website
// Enhanced animations, interactions, and features

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Main initialization function
function initializeApp() {
    initializeLoadingScreen();
    initializeCustomCursor();
    initializeNavigation();
    initializeHeroAnimations();
    initializeParticles();
    initializeScrollEffects();
    initializeAnimations();
    initializeInteractiveFeatures();
    initializeThemeToggle();
    initializeFormHandling();
    initializeTestimonialsCarousel();
    initializeROICalculator();
    initializeMobileOptimizations();
}

// Loading Screen
function initializeLoadingScreen() {
    const loadingScreen = document.querySelector('.loading-screen');
    const loadingProgress = document.querySelector('.loading-progress');
    
    if (!loadingScreen || !loadingProgress) return;
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
                document.body.classList.add('loaded');
            }, 500);
        }
        loadingProgress.style.width = progress + '%';
    }, 100);
}

// Custom Cursor
function initializeCustomCursor() {
    const cursor = document.querySelector('.custom-cursor');
    const cursorDot = document.querySelector('.cursor-dot');
    const cursorOutline = document.querySelector('.cursor-outline');
    
    if (!cursor) return;
    
    let mouseX = 0, mouseY = 0;
    let outlineX = 0, outlineY = 0;
    
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        if (cursorDot) {
            cursorDot.style.left = mouseX + 'px';
            cursorDot.style.top = mouseY + 'px';
        }
    });
    
    function animateCursor() {
        outlineX += (mouseX - outlineX) * 0.1;
        outlineY += (mouseY - outlineY) * 0.1;
        
        if (cursorOutline) {
            cursorOutline.style.left = outlineX + 'px';
            cursorOutline.style.top = outlineY + 'px';
        }
        
        requestAnimationFrame(animateCursor);
    }
    animateCursor();
    
    // Cursor interactions
    const interactiveElements = document.querySelectorAll('a, button, .service-card, .nav-link');
    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
            if (cursorOutline) {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
            }
            if (cursorDot) {
                cursorDot.style.transform = 'translate(-50%, -50%) scale(0.5)';
            }
        });
        
        el.addEventListener('mouseleave', () => {
            if (cursorOutline) {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
            }
            if (cursorDot) {
                cursorDot.style.transform = 'translate(-50%, -50%) scale(1)';
            }
        });
    });
}

// Navigation
function initializeNavigation() {
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (!navbar) return;
    
    // Scroll effects
    let lastScrollY = window.scrollY;
    window.addEventListener('scroll', () => {
        const currentScrollY = window.scrollY;
        
        // Navbar background on scroll
        if (currentScrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        // Hide/show navbar on scroll
        if (currentScrollY > lastScrollY && currentScrollY > 200) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }
        
        lastScrollY = currentScrollY;
        
        // Update scroll progress
        updateScrollProgress();
        
        // Update active navigation
        updateActiveNavigation();
    });
    
    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }
    
    // Close mobile menu on link click
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navToggle) navToggle.classList.remove('active');
            if (navMenu) navMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
        });
    });
    
    // Smooth scrolling for anchor links
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    const offsetTop = target.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// Hero Animations
function initializeHeroAnimations() {
    // Typing animation
    const typingText = document.getElementById('typingText');
    if (typingText) {
        const texts = ['IA Solutions', 'Chatbots', 'Automatisation', 'Marketing IA'];
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        
        function typeText() {
            const currentText = texts[textIndex];
            
            if (isDeleting) {
                typingText.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
            } else {
                typingText.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
            }
            
            let typeSpeed = isDeleting ? 50 : 100;
            
            if (!isDeleting && charIndex === currentText.length) {
                typeSpeed = 2000;
                isDeleting = true;
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                typeSpeed = 500;
            }
            
            setTimeout(typeText, typeSpeed);
        }
        
        setTimeout(typeText, 1000);
    }
    
    // Counter animations
    const statNumbers = document.querySelectorAll('.stat-number');
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.dataset.count);
                animateCounter(counter, target);
                counterObserver.unobserve(counter);
            }
        });
    }, { threshold: 0.5 });
    
    statNumbers.forEach(counter => {
        counterObserver.observe(counter);
    });
}

// Counter animation function
function animateCounter(element, target) {
    let current = 0;
    const increment = target / 100;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target + (element.textContent.includes('+') ? '+' : '');
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current) + (element.textContent.includes('+') ? '+' : '');
        }
    }, 20);
}

// Particles System
function initializeParticles() {
    const particlesContainer = document.getElementById('particles');
    if (!particlesContainer) return;
    
    const particleCount = 50;
    
    for (let i = 0; i < particleCount; i++) {
        createParticle(particlesContainer);
    }
}

function createParticle(container) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    
    // Random position and animation delay
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDelay = Math.random() * 6 + 's';
    particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
    
    container.appendChild(particle);
    
    // Remove and recreate particle after animation
    setTimeout(() => {
        particle.remove();
        createParticle(container);
    }, 6000);
}

// Scroll Effects
function initializeScrollEffects() {
    // Parallax effects
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        
        // Hero parallax
        const heroRobot = document.querySelector('.hero-robot');
        if (heroRobot) {
            const rate = scrolled * -0.5;
            heroRobot.style.transform = `translateY(${rate}px)`;
        }
        
        // Floating elements parallax
        const floatingElements = document.querySelectorAll('.float-element');
        floatingElements.forEach((element, index) => {
            const rate = scrolled * (0.3 + index * 0.1);
            element.style.transform = `translateY(${rate}px)`;
        });
    });
}

// Scroll Progress
function updateScrollProgress() {
    const scrollProgress = document.querySelector('.scroll-progress');
    if (!scrollProgress) return;
    
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;
    
    scrollProgress.style.width = scrolled + '%';
}

// Active Navigation
function updateActiveNavigation() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.clientHeight;
        if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
}

// AOS Animations
function initializeAnimations() {
    // Initialize AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            easing: 'ease-in-out',
            once: true,
            offset: 100
        });
    }
    
    // Custom animations for elements
    const animatedElements = document.querySelectorAll('.service-card, .feature-card, .testimonial-card');
    const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        animationObserver.observe(el);
    });
}

// Interactive Features
function initializeInteractiveFeatures() {
    // Service card interactions
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) scale(1)';
        });
        
        // Click to show details
        card.addEventListener('click', () => {
            showServiceDetails(card);
        });
    });
    
    // Interactive demo
    initializeChatDemo();
    
    // Back to top button
    initializeBackToTop();
}

// Service Details Modal
function showServiceDetails(card) {
    const title = card.querySelector('h3').textContent;
    const description = card.querySelector('p').textContent;
    const features = Array.from(card.querySelectorAll('.service-features li')).map(li => li.textContent);
    
    // Create modal (simplified version)
    const modal = document.createElement('div');
    modal.className = 'service-modal';
    modal.innerHTML = `
        <div class="service-modal-content">
            <span class="service-modal-close">&times;</span>
            <h2>${title}</h2>
            <p>${description}</p>
            <ul>${features.map(feature => `<li>${feature}</li>`).join('')}</ul>
            <button class="btn btn-primary">Demander un devis</button>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Close modal
    modal.querySelector('.service-modal-close').addEventListener('click', () => {
        modal.remove();
        document.body.style.overflow = '';
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            document.body.style.overflow = '';
        }
    });
}

// Chat Demo
function initializeChatDemo() {
    const demoInput = document.getElementById('demoInput');
    const demoChat = document.querySelector('.demo-chat');
    
    if (!demoInput || !demoChat) return;
    
    const responses = [
        "Parfait ! Je peux vous aider à créer un chatbot personnalisé.",
        "Nos solutions IA peuvent automatiser jusqu'à 80% de vos tâches répétitives.",
        "Nous offrons une garantie de satisfaction de 30 jours.",
        "Nos chatbots s'intègrent facilement avec votre CRM existant.",
        "Vous pouvez économiser jusqu'à 40 heures par semaine avec notre automatisation."
    ];
    
    demoInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && demoInput.value.trim()) {
            addMessage(demoInput.value, 'user');
            demoInput.value = '';
            
            setTimeout(() => {
                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                addMessage(randomResponse, 'bot');
            }, 1000);
        }
    });
}

function addMessage(text, sender) {
    const demoChat = document.querySelector('.demo-chat');
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${sender}`;
    
    const avatar = sender === 'bot' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';
    
    messageDiv.innerHTML = `
        <div class="message-avatar">${avatar}</div>
        <div class="message-content">${text}</div>
    `;
    
    demoChat.appendChild(messageDiv);
    demoChat.scrollTop = demoChat.scrollHeight;
}

// Back to Top Button
function initializeBackToTop() {
    const backToTop = document.getElementById('backToTop');
    if (!backToTop) return;
    
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTop.style.opacity = '1';
            backToTop.style.visibility = 'visible';
        } else {
            backToTop.style.opacity = '0';
            backToTop.style.visibility = 'hidden';
        }
    });
    
    backToTop.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Theme Toggle
function initializeThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    
    if (!themeToggle) return;
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.classList.add(savedTheme);
        updateThemeIcon(savedTheme);
    }
    
    themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        const isDark = body.classList.contains('dark-theme');
        
        localStorage.setItem('theme', isDark ? 'dark-theme' : '');
        updateThemeIcon(isDark ? 'dark-theme' : '');
    });
}

function updateThemeIcon(theme) {
    const themeToggle = document.getElementById('themeToggle');
    const icon = themeToggle.querySelector('i');
    
    if (theme === 'dark-theme') {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
}

// Form Handling
function initializeFormHandling() {
    const contactForm = document.getElementById('contactForm');
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);
        
        // Validation
        if (!data.name || !data.email || !data.service) {
            showNotification('Veuillez remplir tous les champs obligatoires.', 'error');
            return;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            showNotification('Veuillez entrer une adresse email valide.', 'error');
            return;
        }
        
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Envoi...';
        submitBtn.disabled = true;
        
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            showNotification('Merci ! Nous vous contacterons bientôt.', 'success');
            contactForm.reset();
        } catch (error) {
            showNotification('Erreur lors de l\'envoi. Veuillez réessayer.', 'error');
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    });
}

// Notification System
function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    const colors = {
        success: '#10B981',
        error: '#EF4444',
        info: '#3B82F6'
    };
    
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: var(--shadow-lg);
        z-index: 10000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        max-width: 300px;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => notification.remove(), 300);
    });
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}
// Testimonials Carousel
function initializeTestimonialsCarousel() {
    const carousel = document.querySelector('.testimonials-carousel');
    const prevBtn = document.getElementById('prevTestimonial');
    const nextBtn = document.getElementById('nextTestimonial');
    const dots = document.querySelectorAll('.carousel-dots .dot');
    
    if (!carousel) return;
    
    let currentSlide = 0;
    const slides = carousel.querySelectorAll('.testimonial-card');
    const totalSlides = slides.length;
    
    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
        
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === index);
        });
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }
    
    if (nextBtn) nextBtn.addEventListener('click', nextSlide);
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);
    
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
        });
    });
    
    // Auto-rotate
    setInterval(nextSlide, 5000);
}

// ROI Calculator
function initializeROICalculator() {
    const employeesSlider = document.getElementById('employees');
    const hoursSlider = document.getElementById('hours');
    const salarySlider = document.getElementById('salary');
    
    const employeesValue = document.getElementById('employeesValue');
    const hoursValue = document.getElementById('hoursValue');
    const salaryValue = document.getElementById('salaryValue');
    
    const annualSavings = document.getElementById('annualSavings');
    const roi = document.getElementById('roi');
    const timeSaved = document.getElementById('timeSaved');
    
    if (!employeesSlider) return;
    
    function updateCalculator() {
        const employees = parseInt(employeesSlider.value);
        const hours = parseInt(hoursSlider.value);
        const salary = parseInt(salarySlider.value);
        
        // Update display values
        if (employeesValue) employeesValue.textContent = employees;
        if (hoursValue) hoursValue.textContent = hours;
        if (salaryValue) salaryValue.textContent = salary + '€';
        
        // Calculate savings
        const weeklySavings = employees * hours * salary * 0.7; // 70% automation
        const annualSavingsAmount = weeklySavings * 52;
        const timeSavedHours = employees * hours * 52;
        
        // Calculate ROI (assuming average AI solution cost)
        const avgMonthlyCost = 400; // Average monthly cost
        const annualCost = avgMonthlyCost * 12;
        const roiPercentage = Math.round(((annualSavingsAmount - annualCost) / annualCost) * 100);
        
        // Animate counters
        if (annualSavings) animateCounter(annualSavings, annualSavingsAmount);
        if (roi) animateCounter(roi, roiPercentage);
        if (timeSaved) animateCounter(timeSaved, timeSavedHours);
        
        // Update display
        if (annualSavings) annualSavings.textContent = '€' + annualSavingsAmount.toLocaleString();
        if (roi) roi.textContent = roiPercentage + '%';
        if (timeSaved) timeSaved.textContent = timeSavedHours.toLocaleString() + 'h';
    }
    
    employeesSlider.addEventListener('input', updateCalculator);
    hoursSlider.addEventListener('input', updateCalculator);
    salarySlider.addEventListener('input', updateCalculator);
    
    // Initial calculation
    updateCalculator();
}

// Mobile Optimizations
function initializeMobileOptimizations() {
    // Touch gestures for carousel
    const carousel = document.querySelector('.testimonials-carousel');
    if (carousel && 'ontouchstart' in window) {
        let startX = 0;
        let startY = 0;
        
        carousel.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        });
        
        carousel.addEventListener('touchend', (e) => {
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // Swipe left - next slide
                    document.getElementById('nextTestimonial')?.click();
                } else {
                    // Swipe right - previous slide
                    document.getElementById('prevTestimonial')?.click();
                }
            }
        });
    }
    
    // Optimize animations for mobile
    if (window.innerWidth < 768) {
        // Reduce animation complexity on mobile
        document.documentElement.style.setProperty('--transition', 'all 0.2s ease');
    }
}

// Performance optimizations
function optimizePerformance() {
    // Lazy loading for images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
    
    // Preload critical resources
    const criticalResources = [
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
    ];
    
    criticalResources.forEach(resource => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = resource;
        link.as = 'style';
        document.head.appendChild(link);
    });
}

// Initialize performance optimizations
optimizePerformance();

// Service Worker for PWA features
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Analytics and tracking
function initializeAnalytics() {
    // Track important interactions
    const trackEvent = (eventName, properties = {}) => {
        // Google Analytics or other analytics service
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, properties);
        }
    };
    
    // Track button clicks
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => {
            trackEvent('button_click', {
                button_text: btn.textContent.trim(),
                button_class: btn.className
            });
        });
    });
    
    // Track form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', () => {
            trackEvent('form_submit', {
                form_id: form.id || 'unknown'
            });
        });
    });
    
    // Track scroll depth
    let maxScroll = 0;
    window.addEventListener('scroll', () => {
        const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
        if (scrollPercent > maxScroll) {
            maxScroll = scrollPercent;
            if (maxScroll % 25 === 0) { // Track every 25%
                trackEvent('scroll_depth', {
                    depth: maxScroll
                });
            }
        }
    });
}

// Initialize analytics
initializeAnalytics();

// Error handling
window.addEventListener('error', (e) => {
    console.error('JavaScript error:', e.error);
    // Send error to analytics or error tracking service
});

// Export functions for global access
window.StarteadyApp = {
    showNotification,
    animateCounter,
    updateScrollProgress
};
    
    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const run = ease(timeElapsed, startPosition, distance, duration);
        window.scrollTo(0, run);
        if (timeElapsed < duration) requestAnimationFrame(animation);
    }
    
    // Easing function for smooth animation
    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }
    
    requestAnimationFrame(animation);
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = this.getAttribute('href');
        smoothScrollTo(target);
    });
});

// Scroll to top functionality
function addScrollToTop() {
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    scrollToTopBtn.className = 'scroll-to-top';
    scrollToTopBtn.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #FF6B9D, #4ECDC4);
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 1000;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    `;
    
    document.body.appendChild(scrollToTopBtn);
    
    // Show/hide scroll to top button
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.style.opacity = '1';
            scrollToTopBtn.style.visibility = 'visible';
        } else {
            scrollToTopBtn.style.opacity = '0';
            scrollToTopBtn.style.visibility = 'hidden';
        }
    });
    
    // Scroll to top on click
    scrollToTopBtn.addEventListener('click', () => {
        smoothScrollTo('#home');
    });
    
    // Hover effects
    scrollToTopBtn.addEventListener('mouseenter', () => {
        scrollToTopBtn.style.transform = 'translateY(-3px) scale(1.1)';
    });
    
    scrollToTopBtn.addEventListener('mouseleave', () => {
        scrollToTopBtn.style.transform = 'translateY(0) scale(1)';
    });
}

// Initialize scroll to top button
document.addEventListener('DOMContentLoaded', addScrollToTop);

// Airtable Configuration (loaded from airtable-config.js)
const AIRTABLE_CONFIG = window.AIRTABLE_CONFIG || {
    baseId: 'YOUR_AIRTABLE_BASE_ID',
    apiKey: 'YOUR_AIRTABLE_API_KEY',
    tableName: 'Contact Submissions'
};

// Contact Form Handling (to backend /api/contact)
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        if (!data.name || !data.email || !data.service) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            showNotification('Please enter a valid email address.', 'error');
            return;
        }
        
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;
        
        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: data.name,
                    email: data.email,
                    company: data.company || '',
                    service: data.service,
                    message: data.message || ''
                })
            });
            const result = await response.json();
            if (response.ok && result.success) {
                showNotification('Thank you! We\'ll get back to you soon.', 'success');
                this.reset();
            } else {
                const errMsg = result?.error || 'Sorry, there was an error. Please try again.';
                showNotification(errMsg, 'error');
            }
        } catch (error) {
            console.error('Form submission error:', error);
            showNotification('Network error. Please try again later.', 'error');
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// Function to submit data to Airtable
async function submitToAirtable(data) {
    const url = `https://api.airtable.com/v0/${AIRTABLE_CONFIG.baseId}/${encodeURIComponent(AIRTABLE_CONFIG.tableName)}`;
    
    const fields = AIRTABLE_CONFIG.fields || {
        name: 'Name',
        email: 'Email',
        company: 'Company',
        service: 'Service',
        message: 'Message',
        dateSubmitted: 'Date Submitted'
    };
    
    const payload = {
        fields: {
            [fields.name]: data.name,
            [fields.email]: data.email,
            [fields.company]: data.company || '',
            [fields.service]: data.service,
            [fields.message]: data.message || '',
            [fields.dateSubmitted]: new Date().toISOString()
        }
    };
    
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${AIRTABLE_CONFIG.apiKey}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`Airtable API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
    }
    
    return await response.json();
}

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        max-width: 300px;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => notification.remove(), 300);
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.service-card, .feature, .stat');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Counter animation for stats
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target + (element.textContent.includes('+') ? '+' : '');
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start) + (element.textContent.includes('+') ? '+' : '');
        }
    }, 16);
}

// Animate counters when they come into view
const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const counter = entry.target.querySelector('.stat-number');
            const text = counter.textContent;
            const number = parseInt(text.replace(/\D/g, ''));
            
            if (number && !counter.dataset.animated) {
                counter.dataset.animated = 'true';
                animateCounter(counter, number);
            }
        }
    });
}, { threshold: 0.5 });

document.addEventListener('DOMContentLoaded', () => {
    const stats = document.querySelectorAll('.stat');
    stats.forEach(stat => counterObserver.observe(stat));
});

// Enhanced Scroll Effects
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    
    // Parallax effect for hero section
    const hero = document.querySelector('.hero');
    const heroRobot = document.querySelector('.hero-robot');
    
    if (hero && heroRobot) {
        const rate = scrolled * -0.5;
        heroRobot.style.transform = `translateY(${rate}px)`;
    }
    
    // Scroll progress indicator
    updateScrollProgress(scrolled);
    
    // Active navigation highlighting
    updateActiveNavigation(scrolled);
});

// Scroll Progress Indicator
function updateScrollProgress(scrolled) {
    const scrollProgress = document.querySelector('.scroll-progress');
    if (!scrollProgress) {
        createScrollProgressBar();
    }
    
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolledPercent = (winScroll / height) * 100;
    
    const progressBar = document.querySelector('.scroll-progress');
    if (progressBar) {
        progressBar.style.width = scrolledPercent + '%';
    }
}

// Create scroll progress bar
function createScrollProgressBar() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(135deg, #FF6B9D, #4ECDC4);
        z-index: 10001;
        transition: width 0.1s ease;
    `;
    document.body.appendChild(progressBar);
}

// Active Navigation Highlighting
function updateActiveNavigation(scrolled) {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.clientHeight;
        if (scrolled >= sectionTop && scrolled < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
}

// Add mobile menu styles dynamically
const mobileMenuStyles = `
    @media (max-width: 768px) {
        .nav-menu {
            position: fixed;
            top: 100%;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            flex-direction: column;
            padding: 2rem;
            transform: translateY(-100%);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .nav-menu.active {
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }
        
        .nav-menu li {
            margin: 1rem 0;
        }
        
        .nav-menu a {
            font-size: 1.2rem;
            padding: 0.5rem 0;
            display: block;
        }
        
        .nav-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        
        .nav-toggle.active span:nth-child(2) {
            opacity: 0;
        }
        
        .nav-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -6px);
        }
    }
`;

// Inject mobile menu styles
const styleSheet = document.createElement('style');
styleSheet.textContent = mobileMenuStyles;
document.head.appendChild(styleSheet);

// Loading animation
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    document.body.classList.remove('loading');
});

// Add loading class to body
document.body.classList.add('loading');

// Fallback: Remove loading class after 3 seconds if load event doesn't fire
setTimeout(() => {
    if (document.body.classList.contains('loading')) {
        document.body.classList.add('loaded');
        document.body.classList.remove('loading');
    }
}, 3000);

// Preloader styles
const preloaderStyles = `
    body.loading {
        overflow: hidden;
    }
    
    body.loaded {
        overflow: auto !important;
    }
    
    body.loading::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    body.loading::after {
        content: '';
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 50px;
        height: 50px;
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-top: 3px solid white;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        z-index: 10000;
    }
    
    @keyframes spin {
        0% { transform: translate(-50%, -50%) rotate(0deg); }
        100% { transform: translate(-50%, -50%) rotate(360deg); }
    }
    
    body.loaded::before,
    body.loaded::after {
        display: none;
    }
`;

const preloaderStyleSheet = document.createElement('style');
preloaderStyleSheet.textContent = preloaderStyles;
document.head.appendChild(preloaderStyleSheet);

// Service card hover effects
document.addEventListener('DOMContentLoaded', () => {
    // Ensure scrolling is enabled
    document.body.classList.add('loaded');
    document.body.classList.remove('loading');
    
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) scale(1)';
        });
    });
});

// Service Details Modal Logic
const serviceDetails = [
  {
    title: 'AI Chatbots',
    icon: '<i class="fas fa-comments"></i>',
    description: 'Intelligent conversational agents that engage customers 24/7, answer questions, and qualify leads automatically.',
    features: [
      '24/7 Customer Support',
      'Lead Qualification',
      'Multi-language Support',
      'Integration Ready'
    ],
    more: `<b>What you get:</b><br>• Custom chatbot flows<br>• Integration with your website or CRM<br>• Analytics dashboard<br>• Human handoff options<br><br><b>Use Cases:</b><br>Customer support, lead capture, appointment booking, FAQs, and more.`
  },
  {
    title: 'Business Automation',
    icon: '<i class="fas fa-cogs"></i>',
    description: 'Streamline operations with AI-powered automation that handles repetitive tasks and improves efficiency.',
    features: [
      'Process Automation',
      'Data Processing',
      'Workflow Optimization',
      'Cost Reduction'
    ],
    more: `<b>What you get:</b><br>• Automated workflows<br>• Integration with existing tools<br>• Custom triggers and actions<br>• Reporting & monitoring<br><br><b>Use Cases:</b><br>Invoice processing, HR onboarding, data entry, and more.`
  },
  {
    title: 'Lead Generation',
    icon: '<i class="fas fa-bullseye"></i>',
    description: 'AI-driven lead generation systems that identify, qualify, and nurture prospects for your business.',
    features: [
      'Prospect Identification',
      'Lead Scoring',
      'Automated Nurturing',
      'ROI Tracking'
    ],
    more: `<b>What you get:</b><br>• Targeted lead lists<br>• Automated outreach<br>• Lead scoring models<br>• CRM integration<br><br><b>Use Cases:</b><br>B2B prospecting, email campaigns, pipeline building, and more.`
  },
  {
    title: 'Marketing AI',
    icon: '<i class="fas fa-chart-line"></i>',
    description: 'Enhance your marketing efforts with AI-powered tools for content creation, optimization, and analytics.',
    features: [
      'Content Optimization',
      'Predictive Analytics',
      'Personalization',
      'Performance Tracking'
    ],
    more: `<b>What you get:</b><br>• AI content suggestions<br>• Campaign analytics<br>• Personalization engines<br>• A/B testing tools<br><br><b>Use Cases:</b><br>Ad optimization, content marketing, customer segmentation, and more.`
  }
];

document.addEventListener('DOMContentLoaded', () => {
  const serviceCards = document.querySelectorAll('.service-card');
  const modal = document.getElementById('service-modal');
  const modalBody = document.getElementById('service-modal-body');
  const modalClose = document.querySelector('.service-modal-close');

  serviceCards.forEach((card, idx) => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', () => {
      const details = serviceDetails[idx];
      modalBody.innerHTML = `
        <div class="service-modal-icon">${details.icon}</div>
        <h2 style="margin-top:0.5rem;">${details.title}</h2>
        <p>${details.description}</p>
        <ul style="margin-bottom:1.2rem;">${details.features.map(f=>`<li>${f}</li>`).join('')}</ul>
        <div class="service-modal-more">${details.more}</div>
      `;
      modal.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    });
  });

  function closeModal() {
    modal.style.display = 'none';
    document.body.style.overflow = '';
  }
  modalClose.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (modal.style.display === 'flex' && (e.key === 'Escape' || e.key === 'Esc')) closeModal();
  });
});

// Typing effect for hero title
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Initialize typing effect when page loads
document.addEventListener('DOMContentLoaded', () => {
    const heroTitle = document.querySelector('.hero-title');
    if (heroTitle) {
        const originalText = heroTitle.textContent;
        setTimeout(() => {
            typeWriter(heroTitle, originalText, 50);
        }, 1000);
    }
});

// Smooth reveal animation for sections
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
        }
    });
}, { threshold: 0.1 });

document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.classList.add('reveal-section');
        revealObserver.observe(section);
    });
});

// Add reveal animation styles
const revealStyles = `
    .reveal-section {
        opacity: 0;
        transform: translateY(50px);
        transition: all 0.8s ease;
    }
    
    .reveal-section.revealed {
        opacity: 1;
        transform: translateY(0);
    }
`;

const revealStyleSheet = document.createElement('style');
revealStyleSheet.textContent = revealStyles;
document.head.appendChild(revealStyleSheet); 