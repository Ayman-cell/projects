# Starteady - Site Web Moderne avec IA

Un site web moderne et dynamique pour une agence IA, créé avec des animations avancées, des interactions fluides et des fonctionnalités PWA.

## 🚀 Fonctionnalités

### ✨ Design & Animations
- **Header moderne** avec logo animé et navigation sticky glassmorphisme
- **Section Hero** avec typing animation, particules 3D et gradients animés
- **Cards de services** avec hover effects 3D et animations avancées
- **Animations AOS** (Animate On Scroll) pour tous les éléments
- **Parallax scrolling** et effets de profondeur
- **Custom cursor** interactif
- **Loading screen** animé avec progression

### 🎯 Fonctionnalités Interactives
- **Calculateur ROI** interactif avec sliders animés
- **Démo chatbot** en direct avec réponses intelligentes
- **Carousel de témoignages** avec navigation tactile
- **Formulaire de contact** avec validation en temps réel
- **Système de notifications** toast modernes
- **Modal de détails** pour les services

### 📱 Mobile & PWA
- **Design responsive** optimisé pour tous les écrans
- **Gestures tactiles** pour le carousel (swipe)
- **PWA complète** avec service worker et manifest
- **Mode sombre/clair** avec persistance
- **Installation** comme app native

### ⚡ Performance & SEO
- **Lazy loading** des images
- **Preconnect** pour les ressources critiques
- **Schema markup** pour le SEO
- **Meta tags** optimisés pour les réseaux sociaux
- **Analytics** intégré pour le tracking
- **Service Worker** pour le cache et l'offline

## 🛠️ Technologies Utilisées

- **HTML5** sémantique et accessible
- **CSS3** avec variables custom et animations avancées
- **JavaScript ES6+** moderne et modulaire
- **AOS Library** pour les animations au scroll
- **Font Awesome** pour les icônes
- **Google Fonts** (Inter & Poppins)
- **Service Worker** pour PWA

## 📁 Structure du Projet

```
starteady-website/
├── index.html          # Page principale
├── styles.css          # Styles CSS avec animations
├── script.js           # JavaScript moderne
├── sw.js              # Service Worker PWA
├── manifest.json      # Manifest PWA
├── logo.png           # Logo de l'entreprise
└── README.md          # Documentation
```

## 🎨 Palette de Couleurs

```css
:root {
    --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --secondary-gradient: linear-gradient(135deg, #FF6B9D, #4ECDC4);
    --accent-gradient: linear-gradient(135deg, #4A90E2, #357ABD);
    --dark-bg: #0a0e27;
    --light-bg: #ffffff;
}
```

## 🚀 Installation & Déploiement

### Développement Local
1. Clonez le repository
2. Ouvrez `index.html` dans votre navigateur
3. Ou utilisez un serveur local :
   ```bash
   python -m http.server 8000
   # ou
   npx serve .
   ```

### Déploiement
- **Vercel** : Connectez votre repository GitHub
- **Netlify** : Drag & drop du dossier
- **GitHub Pages** : Activez dans les settings
- **Serveur web** : Uploadez tous les fichiers

## 📱 Fonctionnalités PWA

Le site est une Progressive Web App complète avec :
- **Installation** sur mobile et desktop
- **Mode offline** avec cache intelligent
- **Notifications push** (configurables)
- **Background sync** pour les formulaires
- **App-like** experience

## 🎯 Sections du Site

1. **Hero** - Présentation avec animations
2. **Services** - 4 services IA avec détails
3. **Fonctionnalités** - Avantages avec démo interactive
4. **Calculateur ROI** - Outil de calcul d'économies
5. **Témoignages** - Carousel de clients satisfaits
6. **Contact** - Formulaire avec validation
7. **Footer** - Liens et informations

## 🔧 Personnalisation

### Modifier les Couleurs
Éditez les variables CSS dans `styles.css` :
```css
:root {
    --primary-gradient: /* Votre gradient */;
    --secondary-gradient: /* Votre gradient */;
}
```

### Ajouter des Services
Modifiez la section services dans `index.html` et ajoutez les styles correspondants.

### Configurer Analytics
Ajoutez votre code Google Analytics dans `script.js` :
```javascript
// Remplacez par votre code GA4
gtag('config', 'GA_MEASUREMENT_ID');
```

## 📊 Performance

- **Lighthouse Score** : 95+ sur tous les critères
- **Core Web Vitals** : Optimisés
- **Mobile-First** : Design responsive
- **Accessibility** : WCAG 2.1 compliant

## 🌟 Fonctionnalités Avancées

- **Typing Animation** pour le titre principal
- **Particles System** en arrière-plan
- **Counter Animations** pour les statistiques
- **Hover Effects** 3D sur les cartes
- **Smooth Scrolling** entre sections
- **Active Navigation** qui suit le scroll
- **Theme Toggle** sombre/clair
- **Form Validation** en temps réel

## 📞 Support

Pour toute question ou personnalisation :
- Email : starteady.agency@gmail.com
- Téléphone : +212 770 28 23 79

## 📄 Licence

Ce projet est sous licence MIT. Libre d'utilisation et de modification.

---

**Starteady** - Transformez votre business avec l'IA 🚀