
  # Create Aesthetic Dashboard Homepage

  This is a code bundle for Create Aesthetic Dashboard Homepage. The original project is available at https://www.figma.com/design/rKhbTN10xTv0JmgDSIElPe/Create-Aesthetic-Dashboard-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  