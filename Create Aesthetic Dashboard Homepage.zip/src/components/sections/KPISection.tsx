import { motion } from "motion/react";
import { TrendingUp, Clock, Target, AlertCircle } from "lucide-react";

export function KPISection() {
  const kpis = [
    {
      icon: Clock,
      title: "Temps de génération",
      value: "Temps réel",
      desc: "Génération instantanée des scénarios",
      color: "#6b8e6f"
    },
    {
      icon: Target,
      title: "Automatisation",
      value: ">70%",
      desc: "Objectif Phase 1",
      color: "#8ab68a"
    },
    {
      icon: AlertCircle,
      title: "Incidents anticipés",
      value: "95%+",
      desc: "Taux de détection proactive",
      color: "#a8c5a3"
    },
    {
      icon: TrendingUp,
      title: "Réduction émissions",
      value: "À définir",
      desc: "En collaboration avec HSE",
      color: "#90be6d"
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#6b8e6f]/10 border border-[#6b8e6f]/30 rounded-full mb-6">
            <TrendingUp className="w-4 h-4 text-[#6b8e6f]" />
            <span className="text-[#6b8e6f] text-sm">Indicateurs de Performance</span>
          </div>
          <h2 className="text-4xl md:text-5xl bg-gradient-to-r from-[#2a3a2e] to-[#6b8e6f] bg-clip-text text-transparent mb-4">
            KPI & Bénéfices
          </h2>
          <p className="text-lg text-[#4a6b4d] max-w-2xl mx-auto">
            Mesurer l'impact opérationnel et la performance du système avec des indicateurs clairs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpis.map((kpi, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ 
                y: -10,
                scale: 1.05,
              }}
              className="relative group"
            >
              <motion.div 
                className="absolute -inset-[2px] rounded-2xl blur-lg"
                style={{ background: `linear-gradient(135deg, ${kpi.color}40, ${kpi.color}20)` }}
                animate={{
                  opacity: [0.3, 0.6, 0.3],
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: i * 0.5,
                }}
              />
              <motion.div 
                className="relative bg-white/90 backdrop-blur-xl border-2 rounded-2xl p-6"
                style={{ borderColor: `${kpi.color}40` }}
                animate={{
                  y: [0, -5, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: i * 0.3,
                }}
              >
                <motion.div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${kpi.color}15`, border: `2px solid ${kpi.color}40` }}
                  animate={{
                    rotate: [0, 360],
                  }}
                  transition={{
                    duration: 10,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                >
                  <motion.div
                    animate={{
                      rotate: [0, -360],
                    }}
                    transition={{
                      duration: 10,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  >
                    <kpi.icon className="w-6 h-6" style={{ color: kpi.color }} />
                  </motion.div>
                </motion.div>
                <h3 className="text-[#2a3a2e] text-sm mb-2">{kpi.title}</h3>
                <motion.div 
                  className="text-3xl mb-2" 
                  style={{ color: kpi.color }}
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.2,
                  }}
                >
                  {kpi.value}
                </motion.div>
                <p className="text-sm text-[#4a6b4d]">{kpi.desc}</p>
              </motion.div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-12 bg-gradient-to-br from-[#6b8e6f]/10 to-[#a8c5a3]/10 border-2 border-[#6b8e6f]/30 rounded-2xl p-8"
        >
          <h3 className="text-2xl text-[#2a3a2e] mb-4 text-center">Métriques techniques</h3>
          <div className="grid md:grid-cols-3 gap-6 text-[#4a6b4d]">
            <div className="text-center">
              <div className="text-lg mb-1">RMSE & MAE</div>
              <div className="text-sm">Pour prévisions météo</div>
            </div>
            <div className="text-center">
              <div className="text-lg mb-1">Taux faux positifs</div>
              <div className="text-sm">Optimisation des alertes</div>
            </div>
            <div className="text-center">
              <div className="text-lg mb-1">Temps de réaction</div>
              <div className="text-sm">Détection → action</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
