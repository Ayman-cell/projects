import { motion } from "motion/react";
import { Server, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function ArchitectureSection() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#6b8e6f]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="w-16 h-16 bg-[#6b8e6f]/10 border-2 border-[#6b8e6f]/30 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Server className="w-8 h-8 text-[#6b8e6f]" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Architecture Back-end & Base de Données</h2>
              <p className="text-lg text-[#4a6b4d]">
                Un back-end sécurisé collecte, stocke et sert données, prévisions et scénarios via API 
                pour le dashboard et la mobile app.
              </p>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#6b8e6f]/20">
              <AccordionTrigger className="text-[#6b8e6f] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#6b8e6f]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Tech stack recommandé</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Python (Django / Flask / FastAPI)</li>
                      <li>PostgreSQL + PostGIS pour données géospatiales</li>
                      <li>TimescaleDB optionnelle pour séries temporelles</li>
                      <li>Redis pour cache et queues</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Services back-end</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Ingestion de données (MQTT/REST listeners)</li>
                      <li>ETL et pré-traitement</li>
                      <li>Serveur modèle ML (/predict endpoint)</li>
                      <li>Orchestration (Airflow / Prefect)</li>
                      <li>Monitoring et logging (ELK stack)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Déploiement</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Conteneurisation Docker</li>
                      <li>Orchestration Kubernetes (optionnel selon infra)</li>
                      <li>Jobs automatiques toutes les 3h pour prédictions</li>
                      <li>Retraining périodique (hebdo ou sur drift détecté)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Monitoring système</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Health checks automatiques</li>
                      <li>Métriques de latence et performance</li>
                      <li>Détection de dérive des données (data drift)</li>
                      <li>Alertes quand RMSE dépasse seuil</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Versioning & traçabilité</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>MLflow pour versioning des modèles</li>
                      <li>Table model_versions en base</li>
                      <li>Audits pour actions prises par opérateurs</li>
                    </ul>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
