import { motion } from "motion/react";
import { Monitor, Smartphone, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function InterfaceSection() {
  return (
    <section className="py-20 px-4 bg-white/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#90be6d]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="w-16 h-16 bg-[#90be6d]/10 border-2 border-[#90be6d]/30 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Monitor className="w-8 h-8 text-[#90be6d]" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Interface & Visualisation</h2>
              <p className="text-lg text-[#4a6b4d]">
                Un <strong>tableau de bord cartographique interactif</strong> (style "Windy") montrera les vents, 
                prévisions, scénarios et actions recommandées. Une application mobile complémentaire permet de 
                recevoir alertes et valider actions à distance.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-[#90be6d]/10 to-[#a8c5a3]/10 border-2 border-[#90be6d]/30 rounded-2xl p-6"
            >
              <Monitor className="w-10 h-10 text-[#90be6d] mb-3" />
              <h3 className="text-[#2a3a2e] mb-2">Dashboard Web (React.js)</h3>
              <ul className="space-y-2 text-sm text-[#4a6b4d]">
                <li>• Carte interactive (Leaflet / Mapbox)</li>
                <li>• Panneaux temps réel (vent, T°, émissions)</li>
                <li>• Timeline des prédictions 3h</li>
                <li>• Liste d'alertes & historique</li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-[#a8c5a3]/10 to-[#8ab68a]/10 border-2 border-[#a8c5a3]/30 rounded-2xl p-6"
            >
              <Smartphone className="w-10 h-10 text-[#a8c5a3] mb-3" />
              <h3 className="text-[#2a3a2e] mb-2">Application Mobile</h3>
              <ul className="space-y-2 text-sm text-[#4a6b4d]">
                <li>• PWA ou app native légère</li>
                <li>• Notifications push en temps réel</li>
                <li>• Validation d'actions à distance</li>
                <li>• Consultation des historiques</li>
              </ul>
            </motion.div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#90be6d]/20">
              <AccordionTrigger className="text-[#90be6d] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#90be6d]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#90be6d] mb-2">Frontend</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>React.js avec TypeScript</li>
                      <li>Composants cartographiques (Leaflet / Mapbox)</li>
                      <li>Widgets pour indicateurs temps réel</li>
                      <li>Timeline des prédictions (graphiques interactifs)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#90be6d] mb-2">Pages clés</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Vue principale (map + indicateurs)</li>
                      <li>Liste d'alertes et scénarios actifs</li>
                      <li>Historique & rapports exportables</li>
                      <li>Page d'administration capteurs</li>
                      <li>Page actions (valider / rejeter)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#90be6d] mb-2">Communication temps réel</h4>
                    <p className="text-[#4a6b4d]">WebSocket pour mise à jour instantanée du dashboard sans rechargement</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
