import { motion, useScroll, useTransform } from "motion/react";
import { Radio, ArrowRight } from "lucide-react";
import { Button } from "../ui/button";

export function HeroSection() {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0.3]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.section
      style={{ opacity, scale }}
      className="min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden"
    >
      {/* Multiple glowing orbs */}
      <motion.div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-[#6b8e6f]/10 rounded-full blur-[120px]"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div 
        className="absolute top-1/3 left-1/3 w-[600px] h-[600px] bg-[#8ab68a]/10 rounded-full blur-[100px]"
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.6, 0.3],
          x: [0, 50, 0],
          y: [0, -50, 0],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div 
        className="absolute bottom-1/3 right-1/3 w-[700px] h-[700px] bg-[#a8c5a3]/10 rounded-full blur-[110px]"
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.4, 0.7, 0.4],
          x: [0, -50, 0],
          y: [0, 50, 0],
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      <div className="container mx-auto text-center relative z-10">
        {/* Logo Badge - 3D Interactive */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ 
            scale: 1.1, 
            rotateX: 5,
            rotateY: 5,
            y: -5,
          }}
          transition={{ duration: 0.3, type: "spring", stiffness: 300 }}
          style={{ perspective: 1000, transformStyle: "preserve-3d" }}
          className="inline-flex items-center gap-3 px-6 py-3 mb-8 relative group cursor-pointer"
        >
          {/* Multi-layer animated glow */}
          <motion.div 
            className="absolute -inset-2 bg-gradient-to-r from-[#6b8e6f]/30 via-[#8ab68a]/30 to-[#a8c5a3]/30 rounded-full blur-2xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.4, 0.8, 0.4],
              rotate: [0, 360],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-[#a8c5a3]/20 via-[#8ab68a]/20 to-[#6b8e6f]/20 rounded-full blur-xl"
            animate={{
              scale: [1.1, 1, 1.1],
              opacity: [0.3, 0.6, 0.3],
              rotate: [360, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          
          <div className="relative flex items-center gap-3 px-8 py-4 bg-white/70 backdrop-blur-2xl border-2 border-white/50 rounded-full shadow-2xl"
            style={{ 
              boxShadow: '0 10px 40px rgba(107, 142, 111, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              transform: 'translateZ(20px)',
            }}
          >
            {/* Shimmer effect */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.5), transparent)',
              }}
              animate={{
                x: ['-200%', '200%'],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              whileHover={{ scale: 1.2 }}
            >
              <Radio className="w-5 h-5 text-[#6b8e6f] drop-shadow-lg" />
            </motion.div>
            <span className="bg-gradient-to-r from-[#2a3a2e] via-[#4a6b4d] to-[#6b8e6f] bg-clip-text text-transparent drop-shadow-sm">
              Airboard — OCP SAFI
            </span>
            <motion.div
              animate={{ 
                scale: [1, 1.8, 1],
                opacity: [1, 0.2, 1]
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-3 h-3 bg-[#6b8e6f] rounded-full"
              style={{
                boxShadow: '0 0 25px rgba(107, 142, 111, 1), 0 0 50px rgba(107, 142, 111, 0.5)',
              }}
            />
          </div>
        </motion.div>

        {/* Main Title - Ultra Animated */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-10"
        >
          <h1 className="text-5xl md:text-7xl lg:text-9xl mb-8 relative">
            {/* First line with 3D effect */}
            <motion.div
              className="inline-block"
              whileHover={{ scale: 1.05, rotateX: 5 }}
              style={{ perspective: 1000 }}
            >
              <motion.span 
                className="bg-gradient-to-r from-[#1a2a1e] via-[#2a3a2e] to-[#4a6b4d] bg-clip-text text-transparent inline-block"
                style={{
                  filter: 'drop-shadow(0 4px 20px rgba(107, 142, 111, 0.3))',
                }}
                animate={{ 
                  y: [0, -12, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                Pilotage Intelligent
              </motion.span>
            </motion.div>
            <br />
            {/* Second line with 3D effect */}
            <motion.div
              className="inline-block"
              whileHover={{ scale: 1.05, rotateX: -5 }}
              style={{ perspective: 1000 }}
            >
              <motion.span 
                className="bg-gradient-to-r from-[#4a6b4d] via-[#6b8e6f] to-[#8ab68a] bg-clip-text text-transparent inline-block"
                style={{
                  filter: 'drop-shadow(0 4px 20px rgba(107, 142, 111, 0.4))',
                }}
                animate={{ 
                  y: [0, -12, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.7,
                }}
              >
                des Émissions
              </motion.span>
            </motion.div>
          </h1>
          
          {/* Animated decorative line with particles */}
          <div className="relative h-12 flex items-center justify-center">
            <motion.div
              animate={{ 
                opacity: [0.2, 1, 0.2],
                scaleX: [0.7, 1.2, 0.7],
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="h-[3px] w-96 rounded-full bg-gradient-to-r from-transparent via-[#6b8e6f] to-transparent"
              style={{
                boxShadow: '0 0 30px rgba(107, 142, 111, 0.6)',
              }}
            />
            {/* Traveling light */}
            <motion.div
              className="absolute h-[5px] w-24 rounded-full bg-gradient-to-r from-transparent via-white to-transparent"
              animate={{
                x: [-250, 250],
                opacity: [0, 1, 1, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
              }}
              style={{
                boxShadow: '0 0 20px rgba(255, 255, 255, 0.8)',
              }}
            />
            {/* Pulsing dots */}
            {[-80, -40, 0, 40, 80].map((x, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-[#6b8e6f] rounded-full"
                style={{ x }}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.2,
                }}
              />
            ))}
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-[#4a6b4d] mb-12 max-w-3xl mx-auto leading-relaxed"
        >
          Pilotage automatique des émissions et recommandations opérationnelles en temps réel, 
          fondées sur les capteurs du site et des modèles prédictifs météo pour <span className="text-[#6b8e6f]">OCP Safi</span>
        </motion.p>

        {/* CTA Buttons - Ultra Interactive */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
        >
          <Button
            onClick={() => scrollToSection('mission')}
            size="lg"
            className="bg-[#6b8e6f] hover:bg-[#4a6b4d] text-white px-8 py-6 text-lg rounded-full group"
          >
            Explorer le système
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button
            onClick={() => scrollToSection('team')}
            size="lg"
            variant="outline"
            className="border-2 border-[#6b8e6f] text-[#4a6b4d] hover:bg-[#6b8e6f]/10 px-8 py-6 text-lg rounded-full"
          >
            Contacter l'équipe HSE
          </Button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="flex flex-col items-center gap-2"
        >
          <span className="text-sm text-[#6b8e6f]/70">Découvrir le projet</span>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-[#6b8e6f]/30 rounded-full flex items-start justify-center p-2"
          >
            <motion.div 
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1.5 h-1.5 bg-[#6b8e6f] rounded-full"
            />
          </motion.div>
        </motion.div>
      </div>
    </motion.section>
  );
}
