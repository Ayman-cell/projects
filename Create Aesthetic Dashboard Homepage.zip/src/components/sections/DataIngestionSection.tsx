import { motion } from "motion/react";
import { Database, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function DataIngestionSection() {
  return (
    <section className="py-20 px-4 bg-white/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#8ab68a]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="w-16 h-16 bg-[#8ab68a]/10 border-2 border-[#8ab68a]/30 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Database className="w-8 h-8 text-[#8ab68a]" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Données & Ingestion</h2>
              <p className="text-lg text-[#4a6b4d]">
                Un collecteur central regroupe les mesures des <strong>~50 capteurs</strong> du site et les historiques, 
                garantissant une donnée propre et traçable pour toutes les analyses.
              </p>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#8ab68a]/20">
              <AccordionTrigger className="text-[#8ab68a] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#8ab68a]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Sources de données</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>~50 capteurs (vitesse/direction vent, T°, humidité, émissions gaz, états machines)</li>
                      <li>Station météo locale</li>
                      <li>Fichiers historiques</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Pipeline d'ingestion</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Ingestion temps réel (MQTT ou REST)</li>
                      <li>Batch pour historique</li>
                      <li>Mise en queue (Kafka/Redis)</li>
                      <li>Validation (timestamps, ranges)</li>
                      <li>Nettoyage (filtrage outliers, interpolation)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Schéma minimal</h4>
                    <div className="bg-[#2a3a2e]/5 rounded-lg p-4 font-mono text-sm">
                      sensor_id, timestamp_utc, lat, lon, type, value, unit, quality_flag
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Politique qualité</h4>
                    <p className="text-[#4a6b4d]">Seuils d'alerte si couverture insuffisante ; mode dégradé si {'>'}X% de données manquantes</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
