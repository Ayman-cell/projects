import { motion } from "motion/react";
import { Mail, Users, FileText, Radio } from "lucide-react";
import { Button } from "../ui/button";

export function TeamSection() {
  return (
    <section id="team" className="py-20 px-4 bg-white/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#6b8e6f]/10 border border-[#6b8e6f]/30 rounded-full mb-6">
            <Users className="w-4 h-4 text-[#6b8e6f]" />
            <span className="text-[#6b8e6f] text-sm">Contact</span>
          </div>
          <h2 className="text-4xl md:text-5xl bg-gradient-to-r from-[#2a3a2e] to-[#6b8e6f] bg-clip-text text-transparent mb-4">
            Équipe & Contact
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#6b8e6f]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl text-[#2a3a2e] mb-2">M. Hicham Smaiti</h3>
            <p className="text-[#6b8e6f]">Responsable Projet HSE — OCP Safi</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-[#6b8e6f]/5 border border-[#6b8e6f]/20 rounded-2xl p-6 text-center"
            >
              <Mail className="w-8 h-8 text-[#6b8e6f] mx-auto mb-3" />
              <h4 className="text-[#2a3a2e] mb-2">Contact Email</h4>
              <Button
                variant="link"
                className="text-[#6b8e6f] hover:text-[#4a6b4d]"
                onClick={() => window.location.href = 'mailto:hse@ocp-safi.ma'}
              >
                hse@ocp-safi.ma
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-[#8ab68a]/5 border border-[#8ab68a]/20 rounded-2xl p-6 text-center"
            >
              <FileText className="w-8 h-8 text-[#8ab68a] mx-auto mb-3" />
              <h4 className="text-[#2a3a2e] mb-2">Documentation</h4>
              <Button
                variant="link"
                className="text-[#8ab68a] hover:text-[#4a6b4d]"
              >
                Télécharger PDF
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-[#a8c5a3]/5 border border-[#a8c5a3]/20 rounded-2xl p-6 text-center"
            >
              <FileText className="w-8 h-8 text-[#a8c5a3] mx-auto mb-3" />
              <h4 className="text-[#2a3a2e] mb-2">Rapports RSE</h4>
              <Button
                variant="link"
                className="text-[#a8c5a3] hover:text-[#4a6b4d]"
              >
                Consulter
              </Button>
            </motion.div>
          </div>

          <div className="mt-8 pt-8 border-t border-[#6b8e6f]/20 text-center">
            <p className="text-[#4a6b4d] mb-4">
              Pour toute question concernant le projet Airboard ou demande de démonstration
            </p>
            <Button
              size="lg"
              className="bg-[#6b8e6f] hover:bg-[#4a6b4d] text-white px-8 rounded-full"
              onClick={() => window.location.href = 'mailto:hse@ocp-safi.ma'}
            >
              <Mail className="w-5 h-5 mr-2" />
              Contacter l'équipe HSE
            </Button>
          </div>
        </motion.div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 pt-12 border-t border-[#6b8e6f]/10 text-center"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-[2px] bg-gradient-to-r from-transparent to-[#6b8e6f]/50" />
            <Radio className="w-5 h-5 text-[#6b8e6f]" />
            <div className="w-8 h-[2px] bg-gradient-to-l from-transparent to-[#6b8e6f]/50" />
          </div>
          <p className="text-[#4a6b4d]/60 text-sm mb-2">
            Airboard — Copyright © 2025 — OCP Safi
          </p>
          <p className="text-[#4a6b4d]/50 text-xs">
            Powered by FastAPI, React, PostgreSQL/PostGIS & Machine Learning
          </p>
        </motion.footer>
      </div>
    </section>
  );
}
