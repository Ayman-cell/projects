import { motion } from "motion/react";
import { Target, Lightbulb, Shield } from "lucide-react";

export function MissionSection() {
  return (
    <section id="mission" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#6b8e6f]/10 border border-[#6b8e6f]/30 rounded-full mb-6">
            <Target className="w-4 h-4 text-[#6b8e6f]" />
            <span className="text-[#6b8e6f] text-sm">Notre Mission</span>
          </div>
          <h2 className="text-4xl md:text-5xl bg-gradient-to-r from-[#2a3a2e] to-[#6b8e6f] bg-clip-text text-transparent mb-6">
            Réduire l'Impact Environnemental
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="absolute -inset-[2px] bg-gradient-to-r from-[#6b8e6f] via-[#8ab68a] to-[#a8c5a3] rounded-3xl blur-xl opacity-20" />
          <div className="relative bg-white/90 backdrop-blur-2xl border-2 border-[#6b8e6f]/30 rounded-3xl p-8 md:p-12 shadow-xl">
            <p className="text-lg text-[#2a3a2e] leading-relaxed mb-8 text-center">
              Notre mission est de <strong className="text-[#6b8e6f]">réduire l'impact environnemental du site Safi</strong> en 
              anticipant les conditions climatiques et en proposant des actions opérationnelles ciblées — 
              décisions guidées par données et modèles prédictifs.
            </p>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  icon: Lightbulb,
                  title: "Anticipation",
                  desc: "Prévisions météo toutes les 3h basées sur 5 ans d'historique",
                  color: "#6b8e6f"
                },
                {
                  icon: Target,
                  title: "Actions Ciblées",
                  desc: "Réduction de cadence, injections anti-odeur, interdictions de démarrage",
                  color: "#8ab68a"
                },
                {
                  icon: Shield,
                  title: "Conformité",
                  desc: "ISO 14001, sécurité IT/OT, protection des données",
                  color: "#a8c5a3"
                }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  whileHover={{ 
                    y: -10,
                    scale: 1.05,
                  }}
                  className="flex flex-col items-center text-center p-6 bg-[#6b8e6f]/5 rounded-2xl border border-[#6b8e6f]/20 hover:border-[#6b8e6f]/40 hover:shadow-xl transition-all relative overflow-hidden group"
                >
                  <motion.div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{
                      background: `radial-gradient(circle at center, ${item.color}10, transparent 70%)`,
                    }}
                    animate={{
                      scale: [1, 1.5, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  />
                  <motion.div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 relative z-10"
                    style={{ backgroundColor: `${item.color}15` }}
                    animate={{
                      rotate: [0, 5, -5, 0],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    <item.icon className="w-6 h-6" style={{ color: item.color }} />
                  </motion.div>
                  <h3 className="text-[#2a3a2e] mb-2 relative z-10">{item.title}</h3>
                  <p className="text-sm text-[#4a6b4d] relative z-10">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
