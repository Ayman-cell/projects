import { motion } from "motion/react";
import { CloudRain, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function ForecastingSection() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          whileHover={{ scale: 1.02 }}
          animate={{
            boxShadow: [
              "0 20px 25px -5px rgba(107, 142, 111, 0.1)",
              "0 25px 50px -12px rgba(107, 142, 111, 0.25)",
              "0 20px 25px -5px rgba(107, 142, 111, 0.1)",
            ],
          }}
          transition={{
            boxShadow: {
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }
          }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#6b8e6f]/30 rounded-3xl p-8 md:p-12 shadow-xl relative overflow-hidden group"
        >
          <motion.div
            className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#6b8e6f]/10 to-transparent rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              x: [0, 20, 0],
              y: [0, -20, 0],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <div className="flex items-start gap-6 mb-6 relative z-10">
            <motion.div 
              className="w-16 h-16 bg-[#6b8e6f]/10 border-2 border-[#6b8e6f]/30 rounded-2xl flex items-center justify-center flex-shrink-0"
              animate={{
                y: [0, -10, 0],
                rotate: [0, 5, -5, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <CloudRain className="w-8 h-8 text-[#6b8e6f]" />
            </motion.div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Prévisions Météorologiques</h2>
              <p className="text-lg text-[#4a6b4d]">
                Prévisions de vent, température et humidité <strong>toutes les 3 heures</strong> pour le site de Safi. 
                Ces prévisions permettent d'anticiper la dispersion des émissions et d'adapter les actions opérationnelles 
                avant qu'un incident n'affecte la ville.
              </p>
            </div>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#6b8e6f]/20">
              <AccordionTrigger className="text-[#6b8e6f] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#6b8e6f]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Horizon et fréquence</h4>
                    <p>Prévisions toutes les <strong>3 heures</strong> (horizon configurable selon les besoins opérationnels)</p>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Données d'entrée</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Historique 5 ans (CSV/Excel)</li>
                      <li>Flux capteurs temps réel</li>
                      <li>API météo externe (si disponible)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Modèles implémentables (progression recommandée)</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li><strong>Baseline:</strong> Persistence & SARIMA</li>
                      <li><strong>Niveau 2:</strong> Gradient Boosting (XGBoost/LightGBM)</li>
                      <li><strong>Niveau 3:</strong> RNN/LSTM ou Transformer pour séquences longues</li>
                      <li><strong>Avancé:</strong> Modèles probabilistes (quantiles/ensembles) pour incertitude</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Évaluation</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>RMSE/MAE par variable</li>
                      <li>Erreur angulaire pour direction du vent</li>
                      <li>Calibration des intervalles de confiance</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#6b8e6f] mb-2">Validation</h4>
                    <p className="text-[#4a6b4d]">Cross-validation temporelle (rolling) + tests saisonniers et par période de quart</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
