import { motion } from "motion/react";
import { GitBranch, ChevronDown, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function ScenariosSection() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#a8c5a3]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="w-16 h-16 bg-[#a8c5a3]/10 border-2 border-[#a8c5a3]/30 rounded-2xl flex items-center justify-center flex-shrink-0">
              <GitBranch className="w-8 h-8 text-[#a8c5a3]" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Scénarios & Actions Automatiques</h2>
              <p className="text-lg text-[#4a6b4d]">
                Le système génère automatiquement des <strong>scénarios (vert / jaune / rouge)</strong> avec recommandations 
                actionnables pour réduire l'impact environnemental.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {[
              { icon: CheckCircle, label: "Scénario Vert", desc: "Conditions normales", color: "#90be6d" },
              { icon: AlertTriangle, label: "Scénario Jaune", desc: "Surveillance accrue", color: "#f9c74f" },
              { icon: XCircle, label: "Scénario Rouge", desc: "Action immédiate", color: "#f94144" }
            ].map((scenario, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white border-2 rounded-2xl p-4 text-center"
                style={{ borderColor: `${scenario.color}40` }}
              >
                <scenario.icon className="w-8 h-8 mx-auto mb-2" style={{ color: scenario.color }} />
                <h4 className="text-[#2a3a2e] mb-1">{scenario.label}</h4>
                <p className="text-sm text-[#4a6b4d]">{scenario.desc}</p>
              </motion.div>
            ))}
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#a8c5a3]/20">
              <AccordionTrigger className="text-[#a8c5a3] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#a8c5a3]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#a8c5a3] mb-2">Actions recommandées</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Réduire cadence de production</li>
                      <li>Surveiller points d'émission précis</li>
                      <li>Interdire démarrage de certains équipements</li>
                      <li>Activer injections anti-odeur</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#a8c5a3] mb-2">Logique des règles</h4>
                    <p className="text-[#4a6b4d]">
                      Combinaison de seuils (vitesse/direction vent, concentration gaz, T°) + logique métier.
                      Exemple : <em>Si vent dirigé vers zone habitée ET émissions {'>'}  seuil → scénario critique</em>
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="text-[#a8c5a3] mb-2">Priorisation</h4>
                    <p className="text-[#4a6b4d]">Score de risque calculé (0–100) pour hiérarchiser les interventions</p>
                  </div>
                  
                  <div>
                    <h4 className="text-[#a8c5a3] mb-2">Automatisation</h4>
                    <p className="text-[#4a6b4d]">
                      Mode semi-automatique (proposition → validation opérateur) puis montée progressive 
                      vers automatisation {'>'} 70% (objectif phase 1)
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="text-[#a8c5a3] mb-2">Traçabilité</h4>
                    <p className="text-[#4a6b4d]">Scénarios stockés en DB, journaux d'actions (audit trail), API pour intégrations</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
