import { motion } from "motion/react";
import { Radio, Brain, Bell, ArrowRight } from "lucide-react";

export function HowItWorksSection() {
  const steps = [
    {
      icon: Radio,
      title: "Collecte Continue",
      desc: "~50 capteurs + sources météo externes",
      color: "#6b8e6f"
    },
    {
      icon: Brain,
      title: "Prévisions ML",
      desc: "Météo toutes les 3h, historique 5 ans",
      color: "#8ab68a"
    },
    {
      icon: Bell,
      title: "Scénarios & Alertes",
      desc: "Actions automatiques web + mobile",
      color: "#a8c5a3"
    }
  ];

  return (
    <section className="py-20 px-4 bg-white/30">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl bg-gradient-to-r from-[#2a3a2e] to-[#6b8e6f] bg-clip-text text-transparent mb-4">
            Comment Ça Marche
          </h2>
          <p className="text-lg text-[#4a6b4d] max-w-2xl mx-auto">
            Un système intelligent en trois étapes pour une gestion environnementale proactive
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connection lines */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-[2px] bg-gradient-to-r from-[#6b8e6f]/30 via-[#8ab68a]/30 to-[#a8c5a3]/30 -translate-y-1/2" />
          
          {steps.map((step, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="relative group"
            >
              <motion.div 
                className="bg-white/90 backdrop-blur-xl border-2 rounded-3xl p-8 shadow-xl relative z-10"
                style={{ borderColor: `${step.color}40` }}
                whileHover={{ 
                  y: -10,
                  scale: 1.05,
                  boxShadow: `0 25px 50px -12px ${step.color}30`,
                }}
                animate={{
                  y: [0, -5, 0],
                }}
                transition={{
                  y: {
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.5,
                  }
                }}
              >
                <motion.div 
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 mx-auto"
                  style={{ backgroundColor: `${step.color}15`, border: `2px solid ${step.color}40` }}
                  animate={{
                    rotate: [0, 360],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    rotate: {
                      duration: 20,
                      repeat: Infinity,
                      ease: "linear",
                    },
                    scale: {
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }
                  }}
                >
                  <motion.div
                    animate={{
                      rotate: [0, -360],
                    }}
                    transition={{
                      duration: 20,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  >
                    <step.icon className="w-8 h-8" style={{ color: step.color }} />
                  </motion.div>
                </motion.div>
                <div className="text-center">
                  <motion.div 
                    className="text-sm mb-2" 
                    style={{ color: step.color }}
                    animate={{
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.3,
                    }}
                  >
                    Étape {i + 1}
                  </motion.div>
                  <h3 className="text-xl text-[#2a3a2e] mb-3">{step.title}</h3>
                  <p className="text-[#4a6b4d]">{step.desc}</p>
                </div>
              </motion.div>
              
              {i < steps.length - 1 && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.5 + i * 0.2 }}
                  className="hidden md:flex absolute top-1/2 -right-4 -translate-y-1/2 z-20"
                >
                  <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center border-2"
                    style={{ borderColor: step.color }}
                  >
                    <ArrowRight className="w-4 h-4" style={{ color: step.color }} />
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
