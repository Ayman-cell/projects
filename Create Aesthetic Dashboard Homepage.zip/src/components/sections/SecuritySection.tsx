import { motion } from "motion/react";
import { Shield, ChevronDown, Lock, Eye, FileCheck } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function SecuritySection() {
  return (
    <section className="py-20 px-4 bg-white/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/90 backdrop-blur-xl border-2 border-[#8ab68a]/30 rounded-3xl p-8 md:p-12 shadow-xl"
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="w-16 h-16 bg-[#8ab68a]/10 border-2 border-[#8ab68a]/30 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Shield className="w-8 h-8 text-[#8ab68a]" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl text-[#2a3a2e] mb-3">Sécurité & Conformité</h2>
              <p className="text-lg text-[#4a6b4d]">
                Le système respecte la confidentialité des données internes OCP et les normes applicables 
                en matière de qualité de l'air (<strong>ISO 14001</strong>). L'accès est restreint via 
                authentification et autorisations.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {[
              { icon: Lock, title: "Authentification", desc: "JWT + RBAC" },
              { icon: Eye, title: "Confidentialité", desc: "NDA & gouvernance" },
              { icon: FileCheck, title: "ISO 14001", desc: "Conformité RSE" }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-[#8ab68a]/5 border border-[#8ab68a]/20 rounded-xl p-4 text-center"
              >
                <item.icon className="w-8 h-8 text-[#8ab68a] mx-auto mb-2" />
                <h4 className="text-[#2a3a2e] mb-1">{item.title}</h4>
                <p className="text-sm text-[#4a6b4d]">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="technical" className="border-[#8ab68a]/20">
              <AccordionTrigger className="text-[#8ab68a] hover:text-[#4a6b4d] hover:no-underline">
                <span className="flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" />
                  Détails techniques
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-[#2a3a2e] space-y-4">
                <div className="bg-[#8ab68a]/5 rounded-xl p-6 space-y-4">
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Auth & RBAC</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>JWT (JSON Web Tokens) pour authentification</li>
                      <li>Rôles définis : opérateur, admin, HSE, auditeur</li>
                      <li>Permissions granulaires par ressource</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Sécurité réseau</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Accès depuis réseau interne OCP (VPN / whitelist IP)</li>
                      <li>Chiffrement TLS pour toutes communications</li>
                      <li>Scans de sécurité réguliers (OWASP)</li>
                      <li>Firewall et segmentation réseau IT/OT</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Gouvernance des données</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Retention policy (conservation limitée)</li>
                      <li>Anonymisation si nécessaire</li>
                      <li>NDA et règles de confidentialité strictes</li>
                      <li>Pas de collecte PII non nécessaire</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Conformité ISO 14001</h4>
                    <ul className="list-disc list-inside space-y-1 text-[#4a6b4d]">
                      <li>Documentation des seuils réglementaires</li>
                      <li>Conservation des rapports RSE exportables</li>
                      <li>Audit trail complet des actions</li>
                      <li>Reporting environnemental automatisé</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-[#8ab68a] mb-2">Tests & Recette</h4>
                    <p className="text-[#4a6b4d]">
                      Phase de recette sur configurations réelles (Chrome/Firefox/Edge), tests fonctionnels, 
                      tests de charge, simulation d'incidents
                    </p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
