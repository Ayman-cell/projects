import { motion, useScroll, useTransform } from "motion/react";
import { AnimatedBackground } from "./AnimatedBackground";
import { ParticleField } from "./ParticleField";
import { HeroSection } from "./sections/HeroSection";
import { MissionSection } from "./sections/MissionSection";
import { HowItWorksSection } from "./sections/HowItWorksSection";
import { ForecastingSection } from "./sections/ForecastingSection";
import { DataIngestionSection } from "./sections/DataIngestionSection";
import { ScenariosSection } from "./sections/ScenariosSection";
import { InterfaceSection } from "./sections/InterfaceSection";
import { ArchitectureSection } from "./sections/ArchitectureSection";
import { SecuritySection } from "./sections/SecuritySection";
import { KPISection } from "./sections/KPISection";
import { TeamSection } from "./sections/TeamSection";
import { useEffect, useState } from "react";

export function HomePage() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const { scrollYProgress } = useScroll();
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.8, 0.6]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[#f5f5f0] overflow-x-hidden relative">
      {/* Animated Background with parallax */}
      <motion.div style={{ y: backgroundY, opacity }} className="fixed inset-0">
        <AnimatedBackground />
      </motion.div>

      {/* Interactive Particle Field */}
      <ParticleField />

      {/* Enhanced Spotlight effect following mouse */}
      <motion.div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(800px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(107, 142, 111, 0.15), transparent 60%)`,
          zIndex: 2,
        }}
      />

      {/* Floating gradient orbs */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="fixed rounded-full pointer-events-none blur-3xl"
          style={{
            width: Math.random() * 300 + 200,
            height: Math.random() * 300 + 200,
            background: `radial-gradient(circle, ${
              ['rgba(107, 142, 111, 0.1)', 'rgba(138, 182, 138, 0.08)', 'rgba(168, 197, 163, 0.09)'][i % 3]
            }, transparent 70%)`,
            zIndex: 0,
          }}
          animate={{
            x: [
              Math.random() * window.innerWidth,
              Math.random() * window.innerWidth,
              Math.random() * window.innerWidth,
            ],
            y: [
              Math.random() * window.innerHeight,
              Math.random() * window.innerHeight,
              Math.random() * window.innerHeight,
            ],
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: Math.random() * 20 + 20,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Main Content */}
      <div className="relative z-10">
        <HeroSection />
        <MissionSection />
        <HowItWorksSection />
        <ForecastingSection />
        <DataIngestionSection />
        <ScenariosSection />
        <InterfaceSection />
        <ArchitectureSection />
        <SecuritySection />
        <KPISection />
        <TeamSection />
      </div>
    </div>
  );
}
