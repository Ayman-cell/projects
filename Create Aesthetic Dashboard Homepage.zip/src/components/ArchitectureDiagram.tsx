import { motion } from "motion/react";
import { Radio, Monitor, Cloud, Database, Lock, Wifi, FileText, Code, Zap, Wind, Thermometer, Droplets, Compass, Sun } from "lucide-react";

export function ArchitectureDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="relative"
    >
      {/* Main Container */}
      <div className="relative">
        {/* Outer glow */}
        <div className="absolute -inset-[3px] bg-gradient-to-r from-[#6b8e6f]/15 via-[#8ab68a]/15 to-[#a8c5a3]/15 rounded-3xl blur-xl" />
        
        {/* Main card */}
        <div className="relative bg-white/90 backdrop-blur-2xl border border-[#6b8e6f]/30 rounded-3xl p-8 md:p-12 shadow-xl">
          {/* Grid Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 lg:gap-6">
            
            {/* Component 1: Weather Station */}
            <ComponentCard
              title="STATION MÉTÉO"
              subtitle="OCP SAFI"
              color="green"
              icon={Radio}
              delay={0.2}
            >
              <div className="space-y-2 mt-4">
                <SensorItem icon={Thermometer} label="Température" delay={0.4} />
                <SensorItem icon={Droplets} label="Humidité" delay={0.5} />
                <SensorItem icon={Wind} label="Vitesse du vent" delay={0.6} />
                <SensorItem icon={Compass} label="Direction du vent" delay={0.7} />
                <SensorItem icon={Sun} label="Rayonnement solaire" delay={0.8} />
              </div>
              <InfoBox delay={0.9} color="green">
                Capteurs mesurent chaque minute
              </InfoBox>
            </ComponentCard>

            {/* Component 2: Local PC */}
            <ComponentCard
              title="PC LOCAL"
              subtitle="Collecte et Transmission"
              color="blue"
              icon={Monitor}
              delay={0.3}
            >
              <div className="space-y-3 mt-4">
                <FileCard icon={FileText} title="mesures.txt" subtitle="Historique local" delay={1.0} />
                <FileCard icon={Code} title="Script Python" subtitle="Détection auto" delay={1.1} />
              </div>
              <InfoBox delay={1.2} color="blue">
                Détecte nouvelle ligne et envoie POST automatiquement
              </InfoBox>
            </ComponentCard>

            {/* Component 3: Backend */}
            <ComponentCard
              title="BACKEND"
              subtitle="FastAPI — Render/Railway"
              color="sage"
              icon={Cloud}
              delay={0.4}
            >
              <div className="space-y-2 mt-4">
                <FeatureItem icon={Database} label="SQLite/JSON Storage" delay={1.3} />
                <FeatureItem icon={Wifi} label="WebSocket Diffusion" delay={1.4} />
                <FeatureItem icon={Lock} label="API_KEY Security" delay={1.5} />
              </div>
              <InfoBox delay={1.6} color="sage">
                POST /api/update<br />
                GET /api/history
              </InfoBox>
            </ComponentCard>

            {/* Component 4: Frontend */}
            <ComponentCard
              title="FRONTEND"
              subtitle="React — Vercel"
              color="lime"
              icon={Monitor}
              delay={0.5}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 1.7 }}
                className="mt-4 bg-[#90be6d]/10 border-2 border-[#90be6d]/30 rounded-xl p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-[#2a3a2e]">Dashboard Live</span>
                  <motion.div
                    animate={{ scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-2 h-2 bg-[#90be6d] rounded-full shadow-[0_0_8px_#90be6d]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="h-8 bg-[#90be6d]/20 rounded border border-[#90be6d]/40" />
                  <div className="h-8 bg-[#90be6d]/20 rounded border border-[#90be6d]/40" />
                  <div className="h-8 bg-[#90be6d]/20 rounded border border-[#90be6d]/40 col-span-2" />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs text-[#2a3a2e]">
                    <Zap className="w-3 h-3 text-[#90be6d]" />
                    <span>Graphiques temps réel</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#2a3a2e]">
                    <Zap className="w-3 h-3 text-[#90be6d]" />
                    <span>Rose des vents</span>
                  </div>
                </div>
              </motion.div>
              <InfoBox delay={1.8} color="lime">
                Mise à jour automatique, pas de rechargement
              </InfoBox>
            </ComponentCard>
          </div>

          {/* Connection Flow Arrows (Desktop only) */}
          <div className="hidden lg:block absolute inset-0 pointer-events-none">
            <svg className="w-full h-full">
              <defs>
                <linearGradient id="flow1" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#6b8e6f" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#8ab68a" stopOpacity="0.5" />
                </linearGradient>
                <linearGradient id="flow2" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#8ab68a" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#a8c5a3" stopOpacity="0.5" />
                </linearGradient>
                <linearGradient id="flow3" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#a8c5a3" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#90be6d" stopOpacity="0.5" />
                </linearGradient>
              </defs>
              
              {/* Animated flow lines */}
              {[
                { id: 1, x1: "23%", x2: "27%", gradient: "flow1" },
                { id: 2, x1: "48%", x2: "52%", gradient: "flow2" },
                { id: 3, x1: "73%", x2: "77%", gradient: "flow3" },
              ].map((line) => (
                <g key={line.id}>
                  <motion.line
                    x1={line.x1}
                    y1="50%"
                    x2={line.x2}
                    y2="50%"
                    stroke={`url(#${line.gradient})`}
                    strokeWidth="2"
                    initial={{ pathLength: 0, opacity: 0 }}
                    whileInView={{ pathLength: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: 0.5 + line.id * 0.2 }}
                  />
                  <motion.circle
                    r="4"
                    fill={`url(#${line.gradient})`}
                    initial={{ offsetDistance: "0%" }}
                    animate={{ offsetDistance: "100%" }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  >
                    <animateMotion dur="2s" repeatCount="indefinite">
                      <mpath href={`#path${line.id}`} />
                    </animateMotion>
                  </motion.circle>
                  <path
                    id={`path${line.id}`}
                    d={`M ${line.x1} 50% L ${line.x2} 50%`}
                    fill="none"
                  />
                </g>
              ))}
            </svg>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function ComponentCard({ title, subtitle, color, icon: Icon, children, delay }: any) {
  const colorMap: any = {
    green: { 
      bg: "bg-white/80", 
      border: "border-[#6b8e6f]/40", 
      text: "text-[#2a3a2e]", 
      glow: "shadow-lg",
      iconBg: "bg-[#6b8e6f]/15"
    },
    blue: { 
      bg: "bg-white/80", 
      border: "border-[#8ab68a]/40", 
      text: "text-[#2a3a2e]", 
      glow: "shadow-lg",
      iconBg: "bg-[#8ab68a]/15"
    },
    sage: { 
      bg: "bg-white/80", 
      border: "border-[#a8c5a3]/40", 
      text: "text-[#2a3a2e]", 
      glow: "shadow-lg",
      iconBg: "bg-[#a8c5a3]/15"
    },
    lime: { 
      bg: "bg-white/80", 
      border: "border-[#90be6d]/40", 
      text: "text-[#2a3a2e]", 
      glow: "shadow-lg",
      iconBg: "bg-[#90be6d]/15"
    },
  };

  const colors = colorMap[color];

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.6, type: "spring", stiffness: 100 }}
      whileHover={{ 
        y: -8,
        transition: { duration: 0.2 }
      }}
      className={`relative ${colors.bg} backdrop-blur-md rounded-2xl border-2 ${colors.border} p-6 ${colors.glow} hover:shadow-2xl hover:scale-[1.02] transition-all group`}
    >
      {/* Icon */}
      <motion.div
        whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
        transition={{ duration: 0.5 }}
        className={`inline-flex items-center justify-center w-14 h-14 ${colors.iconBg} border ${colors.border} rounded-xl mb-4 group-hover:border-opacity-60 transition-all`}
      >
        <Icon className={`w-7 h-7 ${colors.text}`} />
      </motion.div>

      {/* Title */}
      <h3 className={`${colors.text} mb-1`}>{title}</h3>
      <p className="text-xs text-[#4a6b4d]/50 mb-2">{subtitle}</p>

      {/* Children */}
      {children}
    </motion.div>
  );
}

function SensorItem({ icon: Icon, label, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="flex items-center gap-2 text-sm text-[#2a3a2e]"
    >
      <Icon className="w-4 h-4 text-[#6b8e6f]" />
      <span>{label}</span>
    </motion.div>
  );
}

function FileCard({ icon: Icon, title, subtitle, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="flex items-center gap-3 bg-[#8ab68a]/10 border border-[#8ab68a]/30 rounded-lg p-3 hover:bg-[#8ab68a]/20 transition-colors"
    >
      <Icon className="w-5 h-5 text-[#4a6b4d]" />
      <div>
        <div className="text-sm text-[#2a3a2e]">{title}</div>
        <div className="text-xs text-[#4a6b4d]/70">{subtitle}</div>
      </div>
    </motion.div>
  );
}

function FeatureItem({ icon: Icon, label, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="flex items-center gap-2 bg-[#a8c5a3]/10 border border-[#a8c5a3]/30 rounded-lg p-2"
    >
      <Icon className="w-4 h-4 text-[#4a6b4d]" />
      <span className="text-xs text-[#2a3a2e]">{label}</span>
    </motion.div>
  );
}

function InfoBox({ children, delay, color }: any) {
  const colorMap: any = {
    green: "text-[#2a3a2e] bg-[#6b8e6f]/15 border-[#6b8e6f]/30",
    blue: "text-[#2a3a2e] bg-[#8ab68a]/15 border-[#8ab68a]/30",
    sage: "text-[#2a3a2e] bg-[#a8c5a3]/15 border-[#a8c5a3]/30",
    lime: "text-[#2a3a2e] bg-[#90be6d]/15 border-[#90be6d]/30",
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className={`mt-4 text-xs ${colorMap[color]} border-2 rounded-lg p-3 leading-relaxed`}
    >
      {children}
    </motion.div>
  );
}
